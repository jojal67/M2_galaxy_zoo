# -*- coding: utf-8 -*-
import sys
import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import glob
from PIL import Image
from keras.models import Sequential
from keras.layers import Conv2D,MaxPool2D,Flatten,Dense, BatchNormalization, SpatialDropout2D
from keras.models import model_from_json
import keras




def run():

	x=np.load("images_train_set.npy")
	y=np.load("categories_train_set.npy")
	x_train, y_train = x,y

	x=np.load("images_test_set.npy")
	y=np.load("categories_test_set.npy")
	x_test, y_test = x,y 


	print("X_train shape", x_train.shape)
	print("y_train shape", y_train.shape)
	print("X_test shape", x_test.shape)
	print("y_test shape", y_test.shape)

	x_train = x_train.astype('float32')
	x_test = x_test.astype('float32')
	x_train /= 255
	x_test /= 255


	# convert class vectors to binary class matrices
	num_classes = 3
	y_train = keras.utils.to_categorical(y_train, num_classes)
	y_test = keras.utils.to_categorical(y_test, num_classes)
	


	dp=0.1
	#######################
	# Network architecture
	#######################

	model = Sequential()

	model.add(Conv2D(16, (3,3),input_shape=(106, 106, 1),activation='relu'))
	model.add(BatchNormalization()) # New
	#model.add(SpatialDropout2D(dp)) # New
	model.add(MaxPool2D(pool_size=(2,2)))

	
	model.add(Conv2D(32, (3,3),activation='relu'))
	model.add(BatchNormalization()) # New
	#model.add(SpatialDropout2D(dp)) # New
	model.add(MaxPool2D(pool_size=(2,2)))

	
	model.add(Conv2D(64, (3,3),activation='relu')) # New
	model.add(BatchNormalization()) # New
	#model.add(SpatialDropout2D(dp)) # New
	model.add(MaxPool2D(pool_size=(2,2)))          # new
	
	
	model.add(Conv2D(128, (3,3),activation='relu')) # New
	model.add(BatchNormalization()) # New
	#model.add(SpatialDropout2D(dp)) # New
	model.add(MaxPool2D(pool_size=(2,2)))          # new

	model.add(Conv2D(128, (3,3),activation='relu')) # New
	model.add(BatchNormalization()) # New
	#model.add(SpatialDropout2D(dp)) # New
	model.add(MaxPool2D(pool_size=(2,2)))          # new
	

	model.add(Flatten())
	model.add(Dense(128,activation='relu'))
	model.add(Dense(3,activation='softmax'))

	model.summary()
	model.compile(loss=keras.losses.categorical_crossentropy,optimizer='adam',metrics=['accuracy'])




	batch_size = 128
	epochs = 50
	history = model.fit(x_train, y_train,
		  batch_size=batch_size,
		  epochs=epochs,
		  validation_data=(x_test, y_test))

	model_json = model.to_json()
	with open("model.json", "w") as json_file:
		json_file.write(model_json)
	# serialize weights to HDF5
	model.save_weights("trained_network.h5")

	acc_train=np.array(history.history['acc'])
	acc_test=np.array(history.history['val_acc'])
	loss_train=np.array(history.history['loss'])
	loss_test=np.array(history.history['val_loss'])

	np.save("accuracy_train.npy",acc_train)
	np.save("accuracy_test.npy",acc_test)
	np.save("loss_train.npy",loss_train)
	np.save("loss_test.npy",loss_test)













def plot_learning():

	acc_train=np.load("accuracy_train.npy")
	acc_test=np.load("accuracy_test.npy")
	loss_train=np.load("loss_train.npy")
	loss_test=np.load("loss_test.npy")
	epoch=np.linspace(1,len(loss_test),len(loss_test))
	

	plt.figure(11)
	plt.subplot(2,1,1)
	plt.plot(epoch,loss_train,color="r")
	plt.plot(epoch,loss_test,color="b")
	#plt.title('Mean squared error')
	plt.ylabel('MSE',fontsize=20)
	#plt.xlabel('Epochs',fontsize=20)
	plt.legend(['train', 'test'], loc='upper right')

	plt.subplot(2,1,2)
	plt.plot(epoch,acc_train,color="r")
	plt.plot(epoch,acc_test,color="b")
	plt.axhline(0.9,color="k",ls=":")
	plt.axhline(0.8,color="k",ls=":")
	plt.axhline(0.7,color="k",ls=":")
	#plt.title(r'$\mathrm{Coefficient of determination R^2}$',fontsize=20)
	plt.ylabel(r'$\mathrm{R^2}$',fontsize=20)
	plt.xlabel('Epochs',fontsize=20)
	plt.ylim(0,1)
	#plt.legend(['train', 'test'], loc='bottom left')
	
	plt.tight_layout()

	plt.savefig("training.pdf")





def make_prediction():


	images_validation_set=np.load("images_validation_set.npy")
	categories_validation_set=np.load("categories_validation_set.npy")


	images_validation_set = images_validation_set.astype('float32')
	images_validation_set /= 255
	# convert class vectors to binary class matrices
	num_classes = 3
	categories_validation_set = keras.utils.to_categorical(categories_validation_set, num_classes)



	# load json and create model
	json_file = open('model.json', 'r')
	loaded_model_json = json_file.read()
	json_file.close()
	trained_network = model_from_json(loaded_model_json)
	# load weights into new model
	trained_network.load_weights("trained_network.h5")
	print("Loaded model from disk")

	prediction = trained_network.predict(images_validation_set)
	print (prediction.shape)
	print (categories_validation_set.shape)


	# Display all prediction vectors
	#for i in range(len(prediction)):
		#print("real ",categories_validation_set[i], "prediction = ",prediction[i])

	#############
	#  Figure
	#############
	n=36
	countgood=0
	plt.figure(1,figsize=(9.9, 10))
	for i in range(n):		
		a=np.random.randint(0,500)
		indice_group=np.where(categories_validation_set[a]==1)[0][0]
		indice_grp_prediction=np.where(prediction[a]==np.max(prediction[a]))[0][0]
		true=0
		if indice_group==0:
			ax = plt.subplot(np.sqrt(n),np.sqrt(n),i+1)
			plt.imshow(images_validation_set[a][:,:,0].reshape((106,106)))
			plt.text(10,95,"Elliptical",color="g")
			if indice_grp_prediction==0:
				true=1
				plt.text(10,10,"Elliptical",color="r")
			if indice_grp_prediction==1:
				plt.text(10,10,"Disk edge on",color="r")
			if indice_grp_prediction==2:
				plt.text(10,10,"Spiral face on",color="r")
			ax.get_xaxis().set_visible(False)		
			ax.get_yaxis().set_visible(False)	
		if indice_group==1:
			ax = plt.subplot(np.sqrt(n),np.sqrt(n),i+1)
			plt.imshow(images_validation_set[a][:,:,0].reshape((106,106)))
			plt.text(10,95,"Disk edge on",color="g")
			if indice_grp_prediction==0:
				plt.text(10,10,"Elliptical",color="r")
			if indice_grp_prediction==1:
				true=1
				plt.text(10,10,"Disk edge on",color="r")
			if indice_grp_prediction==2:
				plt.text(10,10,"Spiral face on",color="r")
			ax.get_xaxis().set_visible(False)		
			ax.get_yaxis().set_visible(False)	
		if indice_group==2:
			ax = plt.subplot(np.sqrt(n),np.sqrt(n),i+1)
			plt.imshow(images_validation_set[a][:,:,0].reshape((106,106)))
			plt.text(10,95,"Spiral face on",color="g")
			if indice_grp_prediction==0:
				plt.text(10,10,"Elliptical",color="r")
			if indice_grp_prediction==1:
				plt.text(10,10,"Disk edge on",color="r")
			if indice_grp_prediction==2:
				true=1
				plt.text(10,10,"Spiral face on",color="r")
			ax.get_xaxis().set_visible(False)		
			ax.get_yaxis().set_visible(False)

		if true==0:
			plt.plot(np.arange(0,106),np.arange(0,106),c="r")
			plt.plot(np.arange(0,106),np.arange(0,106)[::-1],c="r")
		if true==1:
			plt.plot(np.arange(0,106),np.arange(0,106),c="g")
			plt.plot(np.arange(0,106),np.arange(0,106)[::-1],c="g")
			countgood=countgood+1
	plt.subplots_adjust(wspace=0, hspace=0)
	
	print("There are ",countgood, "galaxies classified correctly over the ",n," galaxies so ","%.2f"%(countgood*100/n), " % of correct classifications")
	plt.savefig("classification.pdf")



	#########################################################
	#          Stat for the whole validation set
	#########################################################
	countgood=0
	for i in range(len(categories_validation_set)):
		indice_group=np.where(categories_validation_set[i]==1)[0][0]
		indice_grp_prediction=np.where(prediction[i]==np.max(prediction[i]))[0][0]
		true=0
		if indice_group==0:
			if indice_grp_prediction==0:
				true=1
		if indice_group==1:
			if indice_grp_prediction==1:
				true=1
		if indice_group==2:
			if indice_grp_prediction==2:
				true=1
		if true==1:		
			countgood=countgood+1

	print("Counts for the whole validation set")
	print("There are ",countgood, "galaxies classified correctly over the ",len(categories_validation_set)," galaxies so ","%.2f"%(countgood*100/len(categories_validation_set)), " % of correct classifications")






##################################################################################################
#
#
#					   Main
#
#
##################################################################################################



run()

plot_learning()

make_prediction()




plt.show()







