# -*- coding: utf-8 -*-
import sys
import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import glob
from PIL import Image






def plot_mosaique(data_path,pathcopy):
	g = glob.glob(data_path+pathcopy+"*.jpg") # find all path names matching this regex pattern
	print("there are ",len(g),"images in total")
	plt.figure(1,figsize=(9.9, 10))
	for i in range(25):
		print(i)
		a=np.random.randint(0,20000)
		im = Image.open(g[a])
		np_im = np.array(im)
		ax = plt.subplot(5,5,i+1)
		plt.imshow(np_im)
		ax.get_xaxis().set_visible(False)		
		ax.get_yaxis().set_visible(False)		
	plt.subplots_adjust(wspace=0, hspace=0)
	







def plot_mosaique_with_3_groups(data_path,pathcopy):
	g = sorted(glob.glob(data_path+pathcopy+"*.jpg")) # find all path names matching this regex pattern
	print("there are ",len(g),"images in total")
	groups=np.load("groups.npy")
	
	cpt_elliptical=0
	cpt_disk_edge_on=0
	cpt_spiral_face_on=0
	cpt_all=0
	
	n=36

	plt.figure(1,figsize=(9.9, 10))
	while cpt_all<n:
		
		a=np.random.randint(0,500)
		name_galaxy=str(g[a][74:80])
		print(groups[a][0], name_galaxy)
		indice_group=np.where(groups[a]==1)[0][0]

		if indice_group==1:	
			cpt_elliptical=cpt_elliptical+1
			if cpt_elliptical<=int(n/3):
				im = Image.open(g[a])
				np_im = np.array(im)
				ax = plt.subplot(np.sqrt(n),np.sqrt(n),cpt_all+1)
				plt.imshow(np_im)
				#plt.text(10,10,name_galaxy,color="g")
				plt.text(10,95,"Elliptical",color="g")
				ax.get_xaxis().set_visible(False)		
				ax.get_yaxis().set_visible(False)	
				cpt_all=cpt_all+1
		
		if indice_group==2:
			cpt_disk_edge_on=cpt_disk_edge_on+1
			if cpt_disk_edge_on<=int(n/3):
				im = Image.open(g[a])
				np_im = np.array(im)
				ax = plt.subplot(np.sqrt(n),np.sqrt(n),cpt_all+1)
				plt.imshow(np_im)
				#plt.text(10,10,name_galaxy,color="g")
				plt.text(10,95,"Disk edge on",color="g")
				ax.get_xaxis().set_visible(False)		
				ax.get_yaxis().set_visible(False)	
				cpt_all=cpt_all+1
			
		if indice_group==3:
			cpt_spiral_face_on=cpt_spiral_face_on+1
			if cpt_spiral_face_on<=int(n/3):
				im = Image.open(g[a])
				np_im = np.array(im)
				ax = plt.subplot(np.sqrt(n),np.sqrt(n),cpt_all+1)
				plt.imshow(np_im)
				#plt.text(10,10,name_galaxy,color="g")
				plt.text(10,95,"Spiral face on",color="g")
				ax.get_xaxis().set_visible(False)		
				ax.get_yaxis().set_visible(False)
				cpt_all=cpt_all+1


		print("cpt elliptical = ",cpt_elliptical," cpt disk edgeon = ", cpt_disk_edge_on, "cpt spiral face on", cpt_spiral_face_on,"cpt all = ",cpt_all)
		
	plt.subplots_adjust(wspace=0, hspace=0)
	plt.savefig(data_path+"mosaique_galaxy_zoo.pdf")









def statistics(data_path,pathcopy):
	groups=np.load("groups.npy")
	cpt_elliptical=0
	cpt_disk_edge_on=0
	cpt_spiral_face_on=0
	for i in range(len(groups)):
		indice_group=np.where(groups[i]==1)[0][0]	
		if indice_group==1:	
			cpt_elliptical=cpt_elliptical+1
		if indice_group==2:
			cpt_disk_edge_on=cpt_disk_edge_on+1	
		if indice_group==3:
			cpt_spiral_face_on=cpt_spiral_face_on+1
	X=np.arange(3)
	categories=np.array(["Elliptical","Disk edge on","Spiral face on"])
	count=np.array([cpt_elliptical,cpt_disk_edge_on,cpt_spiral_face_on])

	print("There are ",cpt_elliptical+cpt_disk_edge_on+cpt_spiral_face_on," galaxies in total")

	fig, ax = plt.subplots()
	width = 0.5  # the width of the bars
	rects1 = ax.bar(X , count, width)
	ax.set_ylabel('Counts')
	#ax.set_xlabel('Category')
	ax.set_title('Number of galaxies in each category')
	ax.set_xticks(X)
	ax.set_xticklabels(("Elliptical","Disk edge on","Spiral face on"))
	










##################################################################################################
#
#
#					   Main
#
#
##################################################################################################


data_path = '/home/chardin/Bureau/TP_deep_learning_M2/galaxy_zoo_classification/'
pathcopy="images/"


#plot_mosaique(data_path,pathcopy)


#plot_mosaique_with_3_groups(data_path,pathcopy)


statistics(data_path,pathcopy)


plt.show()






