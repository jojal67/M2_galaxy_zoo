# -*- coding: utf-8 -*-
import sys
import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import scipy as sc
import scipy.ndimage as ndimage
import glob
from shutil import copyfile 
from PIL import Image
from scipy.misc import imresize
import scipy.misc
import csv


def my_processing(img):
	# 1/ take the central 212*212 part of the original 424*424 image
	# 2/ downsample the 212*212 centered image into a 106*106 image 
	format_img=np.shape(img)
	row,col,depth=format_img[0],format_img[1],format_img[2]
	imcentered=img[int(row/4):int(3*row/4),int(row/4):int(3*row/4),:]
	imdownsampled = imresize(imcentered,size=(106,106,3),interp="cubic")
	return imcentered,imdownsampled




def plot_data_original_and_processed(data_path,pathoriginal,nimage):
	# routine to check the process of downsampling the original sample
	# the original data are in images_training_rev1.zip in "Galaxy_zoo_challenge" on my external hard disk 
	# or in the decompressed folder "data_original" in "Galaxy_zoo_challenge" on my external hard disk
	g = glob.glob(data_path+pathoriginal+"*.jpg") # find all path names matching this regex pattern
	print("there are ",len(g),"images in total")
	plt.figure(1)
	for i in range(nimage):
		print(i)

		im = Image.open(g[i])
		np_im = np.array(im)
		imcentered,imdownsampled=my_processing(np_im)
		print("Original shape = ",np.shape(np_im))
		print("centered shape = ",np.shape(imcentered))
		print("Downsampled shape = ",np.shape(imdownsampled))

		ax = plt.subplot(3,nimage,i+1)
		plt.imshow(np_im)
		ax.get_xaxis().set_visible(False)		
		ax.get_yaxis().set_visible(False)	

		ax = plt.subplot(3,nimage,nimage+i+1)
		plt.imshow(imcentered)
		ax.get_xaxis().set_visible(False)		
		ax.get_yaxis().set_visible(False)

		ax = plt.subplot(3,nimage,nimage+nimage+i+1)
		plt.imshow(imdownsampled)
		ax.get_xaxis().set_visible(False)		
		ax.get_yaxis().set_visible(False)

	plt.subplots_adjust(wspace=0, hspace=0)





def save_processed_data(data_path,pathoriginal,pathcopy):
	g = glob.glob(data_path+pathoriginal+"*.jpg") # find all path names matching this regex pattern
	nombre_images=len(g)
	print("there are ",nombre_images," images in total")
	for i in range(20000):
		print(i)
		im = Image.open(g[i])
		np_im = np.array(im)
		imcentered,imdownsampled=my_processing(np_im)
		name_fig=str(g[i][81:])
		print(name_fig)
		scipy.misc.imsave(pathcopy+name_fig, imdownsampled)



def check_processed_data(pathcopy,nimage):
	g = glob.glob(data_path+pathcopy+"*.jpg") # find all path names matching this regex pattern
	print("there are ",len(g),"images in total")
	plt.figure(1)
	for i in range(nimage):
		print(i)

		im = Image.open(g[i])
		np_im = np.array(im)
		
		print("Original shape = ",np.shape(np_im))
		
		ax = plt.subplot(1,nimage,i+1)
		plt.imshow(np_im)
		ax.get_xaxis().set_visible(False)		
		ax.get_yaxis().set_visible(False)	




def plot_mosaique_processed_data(data_path,pathcopy):
	g = glob.glob(data_path+pathcopy+"*.jpg") # find all path names matching this regex pattern
	print("there are ",len(g),"images in total")
	plt.figure(1,figsize=(9.9, 10))
	for i in range(25):
		print(i)

		a=np.random.randint(0,20000)

		im = Image.open(g[a])
		np_im = np.array(im)
		ax = plt.subplot(5,5,i+1)
		plt.imshow(np_im)

		#plt.axhline(106-0.5,c="r", linewidth=1)
		#plt.axhline(0.5,c="r", linewidth=1)
		#plt.axvline(106-0.5,c="r", linewidth=1)
		#plt.axvline(0.5,c="r", linewidth=1)

		ax.get_xaxis().set_visible(False)		
		ax.get_yaxis().set_visible(False)		
	plt.subplots_adjust(wspace=0, hspace=0)
	plt.savefig(data_path+"mosaique_galaxy_zoo.pdf")






def build_array_annotation(data_path,pathcopy):
	data=np.loadtxt(open("training_solutions_rev1.csv", "rb"), delimiter=",", skiprows=1)
	list_galaxies=[]
	g = glob.glob(data_path+pathcopy+"*.jpg") 
	for i in range(len(g)):
		if i%100==0:
			print(i)
		for j in range(len(data)):
			if int(g[i][82:88])==int(data[j][0]):
				list_galaxies.append(data[j])
				break

	list_galaxies=np.array(list_galaxies)
	print(len(list_galaxies))
	print(np.shape(list_galaxies))
	print(list_galaxies[0:2])
	np.save(data_path+"groups.npy",list_galaxies)






def plot_mosaique_with_groups(data_path,pathcopy):
	g = glob.glob(data_path+pathcopy+"*.jpg") # find all path names matching this regex pattern
	print("there are ",len(g),"images in total")


	groups=np.loadtxt(open("training_solutions_rev1.csv", "rb"), delimiter=",", skiprows=1)

	plt.figure(1,figsize=(9.9, 10))
	for i in range(16):
		
		a=np.random.randint(0,20000)
		name_galaxy=str(g[a][74:80])
		groups_only=groups[a][1:4]
		indice_highest_proba=np.where(groups_only==np.max(groups_only))[0][0]
		print("class = ",indice_highest_proba)
		if indice_highest_proba==0:
			print("Elliptical !!")
		if indice_highest_proba==1:
			print("Spiral !!")


		print(" ")
		print(" ")
		print("Galaxy ",name_galaxy)
		print(groups[a][1:4])
		print("#######################")		
		print("Class 2.1",groups[a][4],"Class 2.2",groups[a][5])
		print("#######################")
		print("Class 3.1",groups[a][6],"Class 3.2",groups[a][7])
		print("#######################")
		print("Class 4.1",groups[a][8],"Class 4.2",groups[a][9])
		print("#######################")
		print("Class 5.1",groups[a][10],"Class 5.2",groups[a][11],"Class 5.3",groups[a][12],"Class 5.4",groups[a][13])
		print("#######################")
		print("Class 6.1",groups[a][14],"Class 6.2",groups[a][15])
		print("#######################")
		print("Class 7.1",groups[a][16],"Class 7.2",groups[a][17],"Class 7.3",groups[a][18])
		print("#######################")
		print("Class 8.1",groups[a][19],"Class 8.2",groups[a][20],"Class 8.3",groups[a][21],"Class 8.4",groups[a][22],"Class 8.5",groups[a][23],"Class 8.6",groups[a][24],"Class 8.7",groups[a][25])
		print("#######################")
		print("Class 9.1",groups[a][26],"Class 9.2",groups[a][27],"Class 9.3",groups[a][28])
		print("#######################")
		print("Class 10.1",groups[a][29],"Class 10.2",groups[a][30],"Class 10.3",groups[a][31])
		print("#######################")
		print("Class 11.1",groups[a][32],"Class 11.2",groups[a][33],"Class 11.3",groups[a][34],"Class 11.4",groups[a][35],"Class 11.5",groups[a][36],"Class 11.6",groups[a][37])
		print(" ")
		print(" ")


		im = Image.open(g[a])
		np_im = np.array(im)
		ax = plt.subplot(4,4,i+1)
		plt.imshow(np_im)
		plt.text(10,10,name_galaxy,color="g")
		plt.text(10,95,"Class "+str(indice_highest_proba),color="g")
		ax.get_xaxis().set_visible(False)		
		ax.get_yaxis().set_visible(False)		
	plt.subplots_adjust(wspace=0, hspace=0)






def plot_mosaique_with_3_groups(data_path,pathcopy):
	g = glob.glob(data_path+pathcopy+"*.jpg") # find all path names matching this regex pattern
	print("there are ",len(g),"images in total")

	groups=np.loadtxt(open("training_solutions_rev1.csv", "rb"), delimiter=",", skiprows=1)
	
	cpt_elliptical=0
	cpt_disk_edge_on=0
	cpt_spiral_face_on=0
	cpt_all=0
	path_elliptical=[]
	path_disk_edge_on=[]
	path_spiral_face_on=[]
	
	n=36

	while (cpt_all<n):
		
		a=np.random.randint(0,20000)
		name_galaxy=str(g[a][74:80])
		groups_only=groups[a][1:4]
		indice_highest_proba=np.where(groups_only==np.max(groups_only))[0][0]
		print("class = ",indice_highest_proba)

		if indice_highest_proba==0:
			question_round=groups[a][16:19]
			indices_round=np.where(question_round==np.max(question_round))[0][0]
			if indices_round==0:
				cpt_elliptical=cpt_elliptical+1
				if cpt_elliptical<=int(n/3):
					path_elliptical.append(g[a])
					cpt_all=cpt_all+1
		if indice_highest_proba==1:
			question_edge_on=groups[a][4:6]
			indices_edge_on=np.where(question_edge_on==np.max(question_edge_on))[0][0]
			if indices_edge_on==0:
				cpt_disk_edge_on=cpt_disk_edge_on+1
				if cpt_disk_edge_on<=int(n/3):
					path_disk_edge_on.append(g[a])
					cpt_all=cpt_all+1
			if indices_edge_on==1:
				question_spirale=groups[a][8:10]
				indices_spirale=np.where(question_spirale==np.max(question_spirale))[0][0]
				if indices_spirale==0:
					cpt_spiral_face_on=cpt_spiral_face_on+1
					if cpt_spiral_face_on<=int(n/3):
						path_spiral_face_on.append(g[a])
						cpt_all=cpt_all+1


		print("cpt elliptical = ",cpt_elliptical," cpt disk edgeon = ", cpt_disk_edge_on, "cpt spiral face on", cpt_spiral_face_on,"cpt all = ",cpt_all)
		


	plt.figure(1,figsize=(9.9, 10))
	for i in range(int(n/3)):
		im = Image.open(path_elliptical[i])
		np_im = np.array(im)
		ax = plt.subplot(np.sqrt(n),np.sqrt(n),i+1)
		plt.imshow(np_im)
		plt.text(10,95,"Elliptical",color="g")
		ax.get_xaxis().set_visible(False)		
		ax.get_yaxis().set_visible(False)	
	for i in range(int(n/3)):
		im = Image.open(path_disk_edge_on[i])
		np_im = np.array(im)
		ax = plt.subplot(np.sqrt(n),np.sqrt(n),int(n/3)+i+1)
		plt.imshow(np_im)
		plt.text(10,95,"Disk edge on",color="g")
		ax.get_xaxis().set_visible(False)		
		ax.get_yaxis().set_visible(False)	
	for i in range(int(n/3)):
		im = Image.open(path_spiral_face_on[i])
		np_im = np.array(im)
		ax = plt.subplot(np.sqrt(n),np.sqrt(n),2*int(n/3)+i+1)
		plt.imshow(np_im)
		plt.text(10,95,"Spiral face on",color="g")
		ax.get_xaxis().set_visible(False)		
		ax.get_yaxis().set_visible(False)		
	plt.subplots_adjust(wspace=0, hspace=0)


##################################################################################################
#
#
#					   Main
#
#
##################################################################################################


data_path = '/home/chardin/Bureau/TP_deep_learning_M2/galaxy_zoo_classification/'
pathoriginal="data_original/"
pathcopy="images/"



nimage=5
#plot_data_original_and_processed(data_path,pathoriginal,nimage)


#save_processed_data(data_path,pathoriginal,pathcopy)


nimage=5
#check_processed_data(pathcopy,nimage)



#plot_mosaique_processed_data(data_path,pathcopy)



#build_array_annotation(data_path,pathcopy)







plt.show()






