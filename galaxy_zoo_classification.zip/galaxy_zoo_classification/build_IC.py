# -*- coding: utf-8 -*-
import sys
import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import glob
from PIL import Image







def make_IC(data_path,pathcopy,resolution,n_training_set,n_test_set,n_validation_set):

	print("there will be ",n_training_set," entries for the training set")
	print("there will be ",n_test_set," entries for the test set")
	print("there will be ",n_validation_set," entries for the validation set")
	
	groups=np.load("groups.npy")

	images_train_set=np.zeros((n_training_set,resolution,resolution,1),dtype=np.int) 
	categories_train_set=np.zeros((n_training_set),dtype=np.int) 

	images_test_set=np.zeros((n_test_set,resolution,resolution,1),dtype=np.int) 
	categories_test_set=np.zeros((n_test_set),dtype=np.int) 

	images_validation_set=np.zeros((n_validation_set,resolution,resolution,1),dtype=np.int) 
	categories_validation_set=np.zeros((n_validation_set),dtype=np.int) 


	indices_elliptical=[]
	indices_disk_edge_on=[]
	indices_spiral_face_on=[]

	indices_elliptical=[]
	indices_disk_edge_on=[]
	indices_spiral_face_on=[]


	############################################################
	# Getting the indices corresponding to the different groups
	############################################################
	for i in range(len(groups)):
		ind=np.where(groups[i]==1)[0][0]
		if ind==1:
			indices_elliptical.append(i)
		if ind==2:
			indices_disk_edge_on.append(i)
		if ind==3:
			indices_spiral_face_on.append(i)
	print(len(indices_elliptical),len(indices_disk_edge_on),len(indices_spiral_face_on))

	
	############################################################
	# 		Generating the training set
	############################################################
	print("Generating training set")
	print(" ")
	cpt=0
	for i in range(int(n_training_set/3)):
		name_gal=str(groups[indices_elliptical[i]][0])
		path_image=data_path+pathcopy+name_gal+".jpg"
		im = Image.open(path_image)
		np_im = np.array(im)
		np_im=np.mean(np_im, -1) # convert RGB in a single channel
		images_train_set[cpt,:,:,0]=np_im
		categories_train_set[cpt]=0
		cpt=cpt+1
	for i in range(int(n_training_set/3)):
		name_gal=str(groups[indices_disk_edge_on[i]][0])
		path_image=data_path+pathcopy+name_gal+".jpg"
		im = Image.open(path_image)
		np_im = np.array(im)
		np_im=np.mean(np_im, -1) # convert RGB in a single channel
		images_train_set[cpt,:,:,0]=np_im
		categories_train_set[cpt]=1
		cpt=cpt+1
	n=n_training_set-2*int(n_training_set/3)	
	for i in range(n):
		name_gal=str(groups[indices_spiral_face_on[i]][0])
		path_image=data_path+pathcopy+name_gal+".jpg"
		im = Image.open(path_image)
		np_im = np.array(im)
		np_im=np.mean(np_im, -1) # convert RGB in a single channel
		images_train_set[cpt,:,:,0]=np_im
		categories_train_set[cpt]=2
		cpt=cpt+1
	
	randomize = np.arange(n_training_set)
	np.random.shuffle(randomize)
	images_train_set = images_train_set[randomize]
	categories_train_set = categories_train_set[randomize]



	############################################################
	# 		Generating the test set
	############################################################
	print("Generating test set")
	print(" ")
	idep=int(n_training_set/3)

	cpt=0
	for i in range(int(n_test_set/3)):
		name_gal=str(groups[indices_elliptical[idep+i]][0])
		path_image=data_path+pathcopy+name_gal+".jpg"
		im = Image.open(path_image)
		np_im = np.array(im)
		np_im=np.mean(np_im, -1) # convert RGB in a single channel
		images_test_set[cpt,:,:,0]=np_im
		categories_test_set[cpt]=0
		cpt=cpt+1
	for i in range(int(n_test_set/3)):
		name_gal=str(groups[indices_disk_edge_on[idep+i]][0])
		path_image=data_path+pathcopy+name_gal+".jpg"
		im = Image.open(path_image)
		np_im = np.array(im)
		np_im=np.mean(np_im, -1) # convert RGB in a single channel
		images_test_set[cpt,:,:,0]=np_im
		categories_test_set[cpt]=1
		cpt=cpt+1
	n=n_test_set-2*int(n_test_set/3)	
	for i in range(n):
		name_gal=str(groups[indices_spiral_face_on[idep+i]][0])
		path_image=data_path+pathcopy+name_gal+".jpg"
		im = Image.open(path_image)
		np_im = np.array(im)
		np_im=np.mean(np_im, -1) # convert RGB in a single channel
		images_test_set[cpt,:,:,0]=np_im
		categories_test_set[cpt]=2
		cpt=cpt+1
	
	randomize = np.arange(n_test_set)
	np.random.shuffle(randomize)
	images_test_set = images_test_set[randomize]
	categories_test_set = categories_test_set[randomize]

	############################################################
	# 		Generating the validation set
	############################################################
	print("Generating validation set")
	print(" ")
	idep=int(n_training_set/3)+int(n_test_set/3)

	cpt=0
	for i in range(int(n_validation_set/3)):
		name_gal=str(groups[indices_elliptical[idep+i]][0])
		path_image=data_path+pathcopy+name_gal+".jpg"
		im = Image.open(path_image)
		np_im = np.array(im)
		np_im=np.mean(np_im, -1) # convert RGB in a single channel
		images_validation_set[cpt,:,:,0]=np_im
		categories_validation_set[cpt]=0
		cpt=cpt+1
	for i in range(int(n_validation_set/3)):
		name_gal=str(groups[indices_disk_edge_on[idep+i]][0])
		path_image=data_path+pathcopy+name_gal+".jpg"
		im = Image.open(path_image)
		np_im = np.array(im)
		np_im=np.mean(np_im, -1) # convert RGB in a single channel
		images_validation_set[cpt,:,:,0]=np_im
		categories_validation_set[cpt]=1
		cpt=cpt+1
	n=n_validation_set-2*int(n_validation_set/3)	
	for i in range(n):
		name_gal=str(groups[indices_spiral_face_on[idep+i]][0])
		path_image=data_path+pathcopy+name_gal+".jpg"
		im = Image.open(path_image)
		np_im = np.array(im)
		np_im=np.mean(np_im, -1) # convert RGB in a single channel
		images_validation_set[cpt,:,:,0]=np_im
		categories_validation_set[cpt]=2
		cpt=cpt+1
	
	randomize = np.arange(n_validation_set)
	np.random.shuffle(randomize)
	images_validation_set = images_validation_set[randomize]
	categories_validation_set = categories_validation_set[randomize]

	"""
	plt.figure(1)
	ax = plt.subplot(1,2,1)
	ax.imshow(np_im)
	ax = plt.subplot(1,2,2)
	a=np.mean(np_im, -1)
	ax.imshow(a)
	print(np.shape(np_im),np.shape(a))
	"""

	#######################################################
	# 	Saving the sets on the disk
	#######################################################
	############################################################
	print("Saving arrays")
	print(" ")
	np.save("images_train_set.npy",images_train_set)
	np.save("categories_train_set.npy",categories_train_set)

	np.save("images_test_set.npy",images_test_set)
	np.save("categories_test_set.npy",categories_test_set)

	np.save("images_validation_set.npy",images_validation_set)
	np.save("categories_validation_set.npy",categories_validation_set)
	

	
	
	



def plot_sample():
	plt.figure(1)
	for i in range(25):
		print(i)
		a=np.random.randint(0,50)
		toto=images_train_set[a,:,:,:]
		ax = plt.subplot(5,5,i+1)
		plt.imshow(toto)
		ax.get_xaxis().set_visible(False)		
		ax.get_yaxis().set_visible(False)		
	plt.subplots_adjust(wspace=0, hspace=0)








##################################################################################################
#
#
#					   Main
#
#
##################################################################################################


data_path = '/home/chardin/Bureau/TP_deep_learning_M2/galaxy_zoo_classification/'
pathcopy="images/"


resolution=106
n_training_set=1000
n_test_set=100
n_validation_set=500
make_IC(data_path,pathcopy,resolution,n_training_set,n_test_set,n_validation_set)



plt.show()
