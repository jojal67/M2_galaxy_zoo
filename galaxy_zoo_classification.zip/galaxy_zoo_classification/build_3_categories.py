# -*- coding: utf-8 -*-
import sys
import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import scipy as sc
import scipy.ndimage as ndimage
import glob
from shutil import copyfile 
from PIL import Image
from scipy.misc import imresize
import scipy.misc
import csv





def my_processing(img):
	# 1/ take the central 212*212 part of the original 424*424 image
	# 2/ downsample the 212*212 centered image into a 106*106 image 
	format_img=np.shape(img)
	row,col,depth=format_img[0],format_img[1],format_img[2]
	imcentered=img[int(row/4):int(3*row/4),int(row/4):int(3*row/4),:]
	imdownsampled = imresize(imcentered,size=(106,106,3),interp="cubic")
	return imcentered,imdownsampled






def keep_all_image_in_categories(data_path,pathoriginal,pathcopy):

	list_galaxies=[]
	data=np.loadtxt(open("training_solutions_rev1.csv", "rb"), delimiter=",", skiprows=1)
	g = sorted(glob.glob(data_path+pathoriginal+"*.jpg")) # find all path names matching this regex pattern
	nombre_images=len(g)
	print("there are ",nombre_images," images in total")

	cpt_all=0
	cpt_elliptical=0
	cpt_disk_edge_on=0
	cpt_spiral_face_on=0

	for i in range(len(g)):
		if i%500==0:
			print(i)
			print (int(g[i][81:87]),int(data[i][0]) )
			print("cpt elliptical = ",cpt_elliptical," cpt disk edgeon = ", cpt_disk_edge_on, "cpt spiral face on", cpt_spiral_face_on,"cpt all = ",cpt_all)
	
		
		groups_only=data[i][1:4]
		indice_highest_proba=np.where(groups_only==np.max(groups_only))[0][0]


		if indice_highest_proba==0:
			question_round=data[i][16:19]
			indices_round=np.where(question_round==np.max(question_round))[0][0]
			if indices_round==0:
				cpt_elliptical=cpt_elliptical+1
				cpt_all=cpt_all+1
				im = Image.open(g[i])
				np_im = np.array(im)
				imcentered,imdownsampled=my_processing(np_im)
				name_fig=str(g[i][81:])
				scipy.misc.imsave(pathcopy+name_fig, imdownsampled)
				list_galaxies.append([int(data[i][0]),1,0,0])


		if indice_highest_proba==1:
			question_edge_on=data[i][4:6]
			indices_edge_on=np.where(question_edge_on==np.max(question_edge_on))[0][0]
			if indices_edge_on==0:
				cpt_disk_edge_on=cpt_disk_edge_on+1
				cpt_all=cpt_all+1
				im = Image.open(g[i])
				np_im = np.array(im)
				imcentered,imdownsampled=my_processing(np_im)
				name_fig=str(g[i][81:])
				scipy.misc.imsave(pathcopy+name_fig, imdownsampled)
				list_galaxies.append([int(data[i][0]),0,1,0])
			if indices_edge_on==1:
				question_spirale=data[i][8:10]
				indices_spirale=np.where(question_spirale==np.max(question_spirale))[0][0]
				if indices_spirale==0:
					cpt_spiral_face_on=cpt_spiral_face_on+1
					cpt_all=cpt_all+1
					im = Image.open(g[i])
					np_im = np.array(im)
					imcentered,imdownsampled=my_processing(np_im)
					name_fig=str(g[i][81:])
					scipy.misc.imsave(pathcopy+name_fig, imdownsampled)
					list_galaxies.append([int(data[i][0]),0,0,1])

	print("cpt elliptical = ",cpt_elliptical," cpt disk edgeon = ", cpt_disk_edge_on, "cpt spiral face on", cpt_spiral_face_on,"cpt all = ",cpt_all)
	
	np.save(data_path+"groups.npy",np.array(list_galaxies))
	
	





##################################################################################################
#
#
#					   Main
#
#
##################################################################################################


data_path = '/home/chardin/Bureau/TP_deep_learning_M2/galaxy_zoo_classification/'
pathoriginal="data_original/"
pathcopy="images/"

keep_all_image_in_categories(data_path,pathoriginal,pathcopy)


